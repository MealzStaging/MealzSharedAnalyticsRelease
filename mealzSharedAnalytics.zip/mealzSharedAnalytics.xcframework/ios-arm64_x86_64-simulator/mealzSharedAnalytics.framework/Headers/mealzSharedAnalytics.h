#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class MSAAbstractSharedAnalyticsCompanion, MSAPlausibleEvent, MSAKotlinEnumCompanion, MSAKotlinEnum<E>, MSAPlatform, MSAKotlinArray<T>, MSAPlausibleProps, MSAAbstractSharedAnalytics, MSASharedAnalytics, MSALogHandlerCompanion, MSALogHandlerLogLevels;

@protocol MSAKotlinComparable, MSAKotlinIterator;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface MSABase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface MSABase (MSABaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface MSAMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface MSAMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorMSAKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface MSANumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface MSAByte : MSANumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface MSAUByte : MSANumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface MSAShort : MSANumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface MSAUShort : MSANumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface MSAInt : MSANumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface MSAUInt : MSANumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface MSALong : MSANumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface MSAULong : MSANumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface MSAFloat : MSANumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface MSADouble : MSANumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface MSABoolean : MSANumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("AbstractSharedAnalytics")))
@interface MSAAbstractSharedAnalytics : MSABase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MSAAbstractSharedAnalyticsCompanion *companion __attribute__((swift_name("companion")));
- (void)doInitDomain:(NSString *)domain version:(NSString *)version abTestKey:(NSString *)abTestKey affiliate:(NSString *)affiliate onEmit:(void (^)(MSAPlausibleEvent *))onEmit __attribute__((swift_name("doInit(domain:version:abTestKey:affiliate:onEmit:)")));
- (void)sendRequestEvent:(MSAPlausibleEvent *)event __attribute__((swift_name("sendRequest(event:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AbstractSharedAnalytics.Companion")))
@interface MSAAbstractSharedAnalyticsCompanion : MSABase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MSAAbstractSharedAnalyticsCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol MSAKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface MSAKotlinEnum<E> : MSABase <MSAKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MSAKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform")))
@interface MSAPlatform : MSAKotlinEnum<MSAPlatform *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MSAPlatform *android __attribute__((swift_name("android")));
@property (class, readonly) MSAPlatform *ios __attribute__((swift_name("ios")));
@property (class, readonly) MSAPlatform *web __attribute__((swift_name("web")));
+ (MSAKotlinArray<MSAPlatform *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MSAPlatform *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlausibleEvent")))
@interface MSAPlausibleEvent : MSABase
- (instancetype)initWithName:(NSString *)name url:(NSString *)url domain:(NSString *)domain props:(MSAPlausibleProps *)props __attribute__((swift_name("init(name:url:domain:props:)"))) __attribute__((objc_designated_initializer));
- (MSAPlausibleEvent *)doCopyName:(NSString *)name url:(NSString *)url domain:(NSString *)domain props:(MSAPlausibleProps *)props __attribute__((swift_name("doCopy(name:url:domain:props:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *domain __attribute__((swift_name("domain")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) MSAPlausibleProps *props __attribute__((swift_name("props")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlausibleProps")))
@interface MSAPlausibleProps : MSABase
- (instancetype)initWithRecipe_id:(NSString * _Nullable)recipe_id category_id:(NSString * _Nullable)category_id entry_name:(NSString * _Nullable)entry_name item_id:(NSString * _Nullable)item_id ext_item_id:(NSString * _Nullable)ext_item_id item_ean:(NSString * _Nullable)item_ean old_item_id:(NSString * _Nullable)old_item_id old_item_ext_id:(NSString * _Nullable)old_item_ext_id old_item_ean:(NSString * _Nullable)old_item_ean new_item_id:(NSString * _Nullable)new_item_id new_item_ext_id:(NSString * _Nullable)new_item_ext_id new_item_ean:(NSString * _Nullable)new_item_ean product_quantity:(NSString * _Nullable)product_quantity basket_id:(NSString * _Nullable)basket_id miam_amount:(NSString * _Nullable)miam_amount total_amount:(NSString * _Nullable)total_amount miam_products:(NSString * _Nullable)miam_products total_products:(NSString * _Nullable)total_products client_order_id:(NSString * _Nullable)client_order_id supplier_id:(NSString * _Nullable)supplier_id pos_id:(NSString * _Nullable)pos_id pos_name:(NSString * _Nullable)pos_name search_term:(NSString * _Nullable)search_term stores_found_count:(NSString * _Nullable)stores_found_count budget:(NSString * _Nullable)budget budget_user:(NSString * _Nullable)budget_user budget_planner:(NSString * _Nullable)budget_planner recipe_count:(NSString * _Nullable)recipe_count guests:(NSString * _Nullable)guests uses_count:(NSString * _Nullable)uses_count time_passed:(NSString * _Nullable)time_passed version:(NSString * _Nullable)version platform:(NSString * _Nullable)platform affiliate:(NSString * _Nullable)affiliate abTestKey:(NSString * _Nullable)abTestKey __attribute__((swift_name("init(recipe_id:category_id:entry_name:item_id:ext_item_id:item_ean:old_item_id:old_item_ext_id:old_item_ean:new_item_id:new_item_ext_id:new_item_ean:product_quantity:basket_id:miam_amount:total_amount:miam_products:total_products:client_order_id:supplier_id:pos_id:pos_name:search_term:stores_found_count:budget:budget_user:budget_planner:recipe_count:guests:uses_count:time_passed:version:platform:affiliate:abTestKey:)"))) __attribute__((objc_designated_initializer));
- (MSAPlausibleProps *)doCopyRecipe_id:(NSString * _Nullable)recipe_id category_id:(NSString * _Nullable)category_id entry_name:(NSString * _Nullable)entry_name item_id:(NSString * _Nullable)item_id ext_item_id:(NSString * _Nullable)ext_item_id item_ean:(NSString * _Nullable)item_ean old_item_id:(NSString * _Nullable)old_item_id old_item_ext_id:(NSString * _Nullable)old_item_ext_id old_item_ean:(NSString * _Nullable)old_item_ean new_item_id:(NSString * _Nullable)new_item_id new_item_ext_id:(NSString * _Nullable)new_item_ext_id new_item_ean:(NSString * _Nullable)new_item_ean product_quantity:(NSString * _Nullable)product_quantity basket_id:(NSString * _Nullable)basket_id miam_amount:(NSString * _Nullable)miam_amount total_amount:(NSString * _Nullable)total_amount miam_products:(NSString * _Nullable)miam_products total_products:(NSString * _Nullable)total_products client_order_id:(NSString * _Nullable)client_order_id supplier_id:(NSString * _Nullable)supplier_id pos_id:(NSString * _Nullable)pos_id pos_name:(NSString * _Nullable)pos_name search_term:(NSString * _Nullable)search_term stores_found_count:(NSString * _Nullable)stores_found_count budget:(NSString * _Nullable)budget budget_user:(NSString * _Nullable)budget_user budget_planner:(NSString * _Nullable)budget_planner recipe_count:(NSString * _Nullable)recipe_count guests:(NSString * _Nullable)guests uses_count:(NSString * _Nullable)uses_count time_passed:(NSString * _Nullable)time_passed version:(NSString * _Nullable)version platform:(NSString * _Nullable)platform affiliate:(NSString * _Nullable)affiliate abTestKey:(NSString * _Nullable)abTestKey __attribute__((swift_name("doCopy(recipe_id:category_id:entry_name:item_id:ext_item_id:item_ean:old_item_id:old_item_ext_id:old_item_ean:new_item_id:new_item_ext_id:new_item_ean:product_quantity:basket_id:miam_amount:total_amount:miam_products:total_products:client_order_id:supplier_id:pos_id:pos_name:search_term:stores_found_count:budget:budget_user:budget_planner:recipe_count:guests:uses_count:time_passed:version:platform:affiliate:abTestKey:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable abTestKey __attribute__((swift_name("abTestKey")));
@property (readonly) NSString * _Nullable affiliate __attribute__((swift_name("affiliate")));
@property (readonly) NSString * _Nullable basket_id __attribute__((swift_name("basket_id")));
@property (readonly) NSString * _Nullable budget __attribute__((swift_name("budget")));
@property (readonly) NSString * _Nullable budget_planner __attribute__((swift_name("budget_planner")));
@property (readonly) NSString * _Nullable budget_user __attribute__((swift_name("budget_user")));
@property (readonly) NSString * _Nullable category_id __attribute__((swift_name("category_id")));
@property (readonly) NSString * _Nullable client_order_id __attribute__((swift_name("client_order_id")));
@property (readonly) NSString * _Nullable entry_name __attribute__((swift_name("entry_name")));
@property (readonly) NSString * _Nullable ext_item_id __attribute__((swift_name("ext_item_id")));
@property (readonly) NSString * _Nullable guests __attribute__((swift_name("guests")));
@property (readonly) NSString * _Nullable item_ean __attribute__((swift_name("item_ean")));
@property (readonly) NSString * _Nullable item_id __attribute__((swift_name("item_id")));
@property (readonly) NSString * _Nullable miam_amount __attribute__((swift_name("miam_amount")));
@property (readonly) NSString * _Nullable miam_products __attribute__((swift_name("miam_products")));
@property (readonly, getter=doNew_item_ean) NSString * _Nullable new_item_ean __attribute__((swift_name("new_item_ean")));
@property (readonly, getter=doNew_item_ext_id) NSString * _Nullable new_item_ext_id __attribute__((swift_name("new_item_ext_id")));
@property (readonly, getter=doNew_item_id) NSString * _Nullable new_item_id __attribute__((swift_name("new_item_id")));
@property (readonly) NSString * _Nullable old_item_ean __attribute__((swift_name("old_item_ean")));
@property (readonly) NSString * _Nullable old_item_ext_id __attribute__((swift_name("old_item_ext_id")));
@property (readonly) NSString * _Nullable old_item_id __attribute__((swift_name("old_item_id")));
@property (readonly) NSString * _Nullable platform __attribute__((swift_name("platform")));
@property (readonly) NSString * _Nullable pos_id __attribute__((swift_name("pos_id")));
@property (readonly) NSString * _Nullable pos_name __attribute__((swift_name("pos_name")));
@property (readonly) NSString * _Nullable product_quantity __attribute__((swift_name("product_quantity")));
@property (readonly) NSString * _Nullable recipe_count __attribute__((swift_name("recipe_count")));
@property (readonly) NSString * _Nullable recipe_id __attribute__((swift_name("recipe_id")));
@property (readonly) NSString * _Nullable search_term __attribute__((swift_name("search_term")));
@property (readonly) NSString * _Nullable stores_found_count __attribute__((swift_name("stores_found_count")));
@property (readonly) NSString * _Nullable supplier_id __attribute__((swift_name("supplier_id")));
@property (readonly) NSString * _Nullable time_passed __attribute__((swift_name("time_passed")));
@property (readonly) NSString * _Nullable total_amount __attribute__((swift_name("total_amount")));
@property (readonly) NSString * _Nullable total_products __attribute__((swift_name("total_products")));
@property (readonly) NSString * _Nullable uses_count __attribute__((swift_name("uses_count")));
@property (readonly) NSString * _Nullable version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SharedAnalytics")))
@interface MSASharedAnalytics : MSAAbstractSharedAnalytics
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (instancetype)sharedAnalytics __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MSASharedAnalytics *shared __attribute__((swift_name("shared")));
- (void)doInitSharedAnalyticsDomain:(NSString *)domain version:(NSString *)version abTestKey:(NSString *)abTestKey affiliate:(NSString *)affiliate onEmit:(void (^)(MSAPlausibleEvent *))onEmit __attribute__((swift_name("doInitSharedAnalytics(domain:version:abTestKey:affiliate:onEmit:)")));
- (void)sendPlausibleRequestPlausiblePath:(NSString *)plausiblePath path:(NSString *)path plausibleProps:(MSAPlausibleProps *)plausibleProps __attribute__((swift_name("sendPlausibleRequest(plausiblePath:path:plausibleProps:)")));
- (void)sendRequestEvent:(MSAPlausibleEvent *)event __attribute__((swift_name("sendRequest(event:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler")))
@interface MSALogHandler : MSABase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MSALogHandlerCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.Companion")))
@interface MSALogHandlerCompanion : MSABase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MSALogHandlerCompanion *shared __attribute__((swift_name("shared")));
@property void (^debug)(NSString *) __attribute__((swift_name("debug")));
@property void (^error)(NSString *) __attribute__((swift_name("error")));
@property void (^info)(NSString *) __attribute__((swift_name("info")));
@property BOOL keepLog __attribute__((swift_name("keepLog")));
@property MSALogHandlerLogLevels *logLevel __attribute__((swift_name("logLevel")));
@property NSString *stackTrace __attribute__((swift_name("stackTrace")));
@property void (^warn)(NSString *) __attribute__((swift_name("warn")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.LogLevels")))
@interface MSALogHandlerLogLevels : MSAKotlinEnum<MSALogHandlerLogLevels *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MSALogHandlerLogLevels *allLogs __attribute__((swift_name("allLogs")));
@property (class, readonly) MSALogHandlerLogLevels *errorsOnly __attribute__((swift_name("errorsOnly")));
@property (class, readonly) MSALogHandlerLogLevels *errorsAndWarns __attribute__((swift_name("errorsAndWarns")));
@property (class, readonly) MSALogHandlerLogLevels *noLogs __attribute__((swift_name("noLogs")));
+ (MSAKotlinArray<MSALogHandlerLogLevels *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MSALogHandlerLogLevels *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketKt")))
@interface MSABasketKt : MSABase
+ (void)sendBasketConfirmedEventPath:(NSString *)path pointOfSaleName:(NSString *)pointOfSaleName pointOfSaleId:(NSString *)pointOfSaleId mealzAmount:(NSString *)mealzAmount totalAmount:(NSString *)totalAmount basketId:(NSString *)basketId recipeCount:(NSString *)recipeCount mealzProducts:(NSString *)mealzProducts totalProducts:(NSString * _Nullable)totalProducts clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("sendBasketConfirmedEvent(path:pointOfSaleName:pointOfSaleId:mealzAmount:totalAmount:basketId:recipeCount:mealzProducts:totalProducts:clientOrderId:)")));
+ (void)sendBasketTransferEventPath:(NSString *)path pointOfSaleName:(NSString *)pointOfSaleName pointOfSaleId:(NSString *)pointOfSaleId mealzAmount:(NSString *)mealzAmount basketId:(NSString *)basketId supplierId:(NSString *)supplierId __attribute__((swift_name("sendBasketTransferEvent(path:pointOfSaleName:pointOfSaleId:mealzAmount:basketId:supplierId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogKt")))
@interface MSACatalogKt : MSABase
+ (void)sendCategoryDisplayEventPath:(NSString *)path categoryId:(NSString *)categoryId __attribute__((swift_name("sendCategoryDisplayEvent(path:categoryId:)")));
+ (void)sendCategoryShowEventPath:(NSString *)path categoryId:(NSString *)categoryId __attribute__((swift_name("sendCategoryShowEvent(path:categoryId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EntryKt")))
@interface MSAEntryKt : MSABase
+ (void)sendEntryAddEventPath:(NSString *)path entryName:(NSString *)entryName itemId:(NSString *)itemId extItemId:(NSString *)extItemId itemEAN:(NSString *)itemEAN productQuantity:(NSString *)productQuantity recipeId:(NSString * _Nullable)recipeId __attribute__((swift_name("sendEntryAddEvent(path:entryName:itemId:extItemId:itemEAN:productQuantity:recipeId:)")));
+ (void)sendEntryChangeQuantityEventPath:(NSString *)path entryName:(NSString *)entryName itemId:(NSString *)itemId extItemId:(NSString *)extItemId itemEAN:(NSString *)itemEAN productQuantity:(NSString *)productQuantity recipeId:(NSString * _Nullable)recipeId __attribute__((swift_name("sendEntryChangeQuantityEvent(path:entryName:itemId:extItemId:itemEAN:productQuantity:recipeId:)")));
+ (void)sendEntryDeleteEventPath:(NSString *)path entryName:(NSString *)entryName itemId:(NSString *)itemId extItemId:(NSString *)extItemId itemEAN:(NSString *)itemEAN productQuantity:(NSString *)productQuantity recipeId:(NSString * _Nullable)recipeId __attribute__((swift_name("sendEntryDeleteEvent(path:entryName:itemId:extItemId:itemEAN:productQuantity:recipeId:)")));
+ (void)sendEntryReplaceEventPath:(NSString *)path entryName:(NSString *)entryName newItemId:(NSString *)newItemId newItemExtId:(NSString *)newItemExtId newItemEAN:(NSString *)newItemEAN oldItemId:(NSString *)oldItemId oldItemExtId:(NSString *)oldItemExtId oldItemEAN:(NSString *)oldItemEAN productQuantity:(NSString *)productQuantity searchTerm:(NSString * _Nullable)searchTerm recipeId:(NSString * _Nullable)recipeId __attribute__((swift_name("sendEntryReplaceEvent(path:entryName:newItemId:newItemExtId:newItemEAN:oldItemId:oldItemExtId:oldItemEAN:productQuantity:searchTerm:recipeId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InitKt")))
@interface MSAInitKt : MSABase
+ (void)doInitSharedAnalyticsDomain:(NSString *)domain version:(NSString *)version abTestKey:(NSString *)abTestKey affiliate:(NSString *)affiliate onEmit:(void (^)(MSAPlausibleEvent *))onEmit __attribute__((swift_name("doInitSharedAnalytics(domain:version:abTestKey:affiliate:onEmit:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerKt")))
@interface MSAMealPlannerKt : MSABase
+ (void)sendPlannerConfirmEventPath:(NSString *)path budgetUser:(NSString *)budgetUser budgetPlanner:(NSString *)budgetPlanner recipeCount:(NSString *)recipeCount guests:(NSString *)guests usesCount:(NSString *)usesCount timePassed:(NSString *)timePassed __attribute__((swift_name("sendPlannerConfirmEvent(path:budgetUser:budgetPlanner:recipeCount:guests:usesCount:timePassed:)")));
+ (void)sendPlannerFinalizeEventPath:(NSString *)path budgetUser:(NSString *)budgetUser budgetPlanner:(NSString *)budgetPlanner recipeCount:(NSString *)recipeCount guests:(NSString *)guests __attribute__((swift_name("sendPlannerFinalizeEvent(path:budgetUser:budgetPlanner:recipeCount:guests:)")));
+ (void)sendPlannerRecipeDeletedEventPath:(NSString *)path recipeId:(NSString *)recipeId __attribute__((swift_name("sendPlannerRecipeDeletedEvent(path:recipeId:)")));
+ (void)sendPlannerStartedEventPath:(NSString *)path budget:(NSString *)budget guests:(NSString *)guests recipeCount:(NSString *)recipeCount __attribute__((swift_name("sendPlannerStartedEvent(path:budget:guests:recipeCount:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PageViewKt")))
@interface MSAPageViewKt : MSABase
+ (void)sendPageViewEventPath:(NSString *)path __attribute__((swift_name("sendPageViewEvent(path:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaymentKt")))
@interface MSAPaymentKt : MSABase
+ (void)sendPaymentConfirmedEventPath:(NSString *)path pointOfSaleName:(NSString *)pointOfSaleName pointOfSaleId:(NSString *)pointOfSaleId mealzAmount:(NSString *)mealzAmount totalAmount:(NSString *)totalAmount basketId:(NSString *)basketId recipeCount:(NSString *)recipeCount mealzProducts:(NSString *)mealzProducts totalProducts:(NSString * _Nullable)totalProducts clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("sendPaymentConfirmedEvent(path:pointOfSaleName:pointOfSaleId:mealzAmount:totalAmount:basketId:recipeCount:mealzProducts:totalProducts:clientOrderId:)")));
+ (void)sendPaymentStartedEventPath:(NSString *)path pointOfSaleName:(NSString *)pointOfSaleName pointOfSaleId:(NSString *)pointOfSaleId mealzAmount:(NSString *)mealzAmount totalAmount:(NSString *)totalAmount basketId:(NSString *)basketId recipeCount:(NSString *)recipeCount mealzProducts:(NSString *)mealzProducts totalProducts:(NSString * _Nullable)totalProducts clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("sendPaymentStartedEvent(path:pointOfSaleName:pointOfSaleId:mealzAmount:totalAmount:basketId:recipeCount:mealzProducts:totalProducts:clientOrderId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform_iosKt")))
@interface MSAPlatform_iosKt : MSABase
+ (MSAPlatform *)getPlatform __attribute__((swift_name("getPlatform()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeKt")))
@interface MSARecipeKt : MSABase
+ (void)sendRecipeAddEventPath:(NSString *)path recipeId:(NSString *)recipeId __attribute__((swift_name("sendRecipeAddEvent(path:recipeId:)")));
+ (void)sendRecipeChangeGuestsEventPath:(NSString *)path recipeId:(NSString *)recipeId __attribute__((swift_name("sendRecipeChangeGuestsEvent(path:recipeId:)")));
+ (void)sendRecipeDisplayEventPath:(NSString *)path recipeId:(NSString *)recipeId categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("sendRecipeDisplayEvent(path:recipeId:categoryId:)")));
+ (void)sendRecipeLikeEventPath:(NSString *)path recipeId:(NSString *)recipeId categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("sendRecipeLikeEvent(path:recipeId:categoryId:)")));
+ (void)sendRecipeRemoveEventPath:(NSString *)path recipeId:(NSString *)recipeId __attribute__((swift_name("sendRecipeRemoveEvent(path:recipeId:)")));
+ (void)sendRecipeShowEventPath:(NSString *)path recipeId:(NSString *)recipeId categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("sendRecipeShowEvent(path:recipeId:categoryId:)")));
+ (void)sendRecipeSponsorEventPath:(NSString *)path recipeId:(NSString *)recipeId __attribute__((swift_name("sendRecipeSponsorEvent(path:recipeId:)")));
+ (void)sendRecipeUnlikeEventPath:(NSString *)path recipeId:(NSString *)recipeId categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("sendRecipeUnlikeEvent(path:recipeId:categoryId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SearchKt")))
@interface MSASearchKt : MSABase
+ (void)sendSearchEventPath:(NSString *)path searchTerm:(NSString *)searchTerm __attribute__((swift_name("sendSearchEvent(path:searchTerm:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreLocatorKt")))
@interface MSAStoreLocatorKt : MSABase
+ (void)sendPointOfSaleSelectedEventPath:(NSString *)path pointOfSaleName:(NSString *)pointOfSaleName pointOfSaleId:(NSString *)pointOfSaleId __attribute__((swift_name("sendPointOfSaleSelectedEvent(path:pointOfSaleName:pointOfSaleId:)")));
+ (void)sendSearchStoreEventPath:(NSString *)path searchTerm:(NSString *)searchTerm storesFoundCount:(NSString *)storesFoundCount __attribute__((swift_name("sendSearchStoreEvent(path:searchTerm:storesFoundCount:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface MSAKotlinEnumCompanion : MSABase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MSAKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface MSAKotlinArray<T> : MSABase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(MSAInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<MSAKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol MSAKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
